package com.products.service;

import org.json.simple.JSONObject;

public interface ProductsService {
	public JSONObject productsResponse(String string, String string2, String string3);

}
