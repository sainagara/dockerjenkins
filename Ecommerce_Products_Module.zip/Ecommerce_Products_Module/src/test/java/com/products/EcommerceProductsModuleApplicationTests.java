package com.products;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommerceProductsModuleApplicationTests {

	@Test
	void contextLoads() {
	}

}
