package com.user;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommerceUserRegistrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
